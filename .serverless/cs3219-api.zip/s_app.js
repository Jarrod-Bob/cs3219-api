
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'ngjunguangjarrod',
  applicationName: 'cs3219-api-app',
  appUid: 'rVz8fr9td0blLPb63V',
  orgUid: 'YBvtjnnKxf9W0k1Cll',
  deploymentUid: 'd7708b7d-53a1-4b74-9012-070dcb0beaa0',
  serviceName: 'cs3219-api',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '4.1.2',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'cs3219-api-dev-app', timeout: 6 };

try {
  const userHandler = require('././src/index.js');
  module.exports.handler = serverlessSDK.handler(userHandler.handler, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}